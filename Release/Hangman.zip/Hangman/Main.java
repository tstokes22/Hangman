//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;


public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        ReadFile readfile = new ReadFile();

        ArrayList<String> words = new ArrayList<String>();
        ArrayList<String> letters = new ArrayList<String>();
        ArrayList<String> guessContainer = new ArrayList<String>();
        ArrayList<String> guessedWords = new ArrayList<String>();

        readfile.readFile(words);
        Random r = new Random();

        String guess;
        boolean won = true;
        int count = 0;
        int livesAmount = 9;

        int r1 = r.nextInt(words.size());
        String randomWord = "";

        randomWord = words.get(r1);

        System.out.print("Welcome to hangman, try and guess the word. \n");
        for (int i = 0; i < randomWord.length(); i++) {

            guessContainer.add("_");
            System.out.print(" " + guessContainer.get(i));
            letters.add("" + randomWord.charAt(i));
        }

        do {
            System.out.print("\nPlease enter your guess: ");
            guess = sc.nextLine();

            for(int i = 0; i < guess.length(); i++){
                if(guessedWords.contains(String.valueOf(guess.charAt(i)))){
                    System.out.print("Already guessed that letter(s): " + guess.charAt(i) + '\n');
                }

                if (!letters.contains(String.valueOf(guess.charAt(i))) & !letters.contains(String.valueOf(guess.toUpperCase().charAt(i))) & !guessedWords.contains(String.valueOf(guess.charAt(i))) & !guessedWords.contains(String.valueOf(guess.toUpperCase().charAt(i)))){
                    livesAmount--;
                }
                guessedWords.add(String.valueOf(guess.charAt(i)));
            }

            System.out.print("Guessed list: " + guessedWords);
            System.out.print("\nLives: " + livesAmount + '\n' );

            for (int i = 0; i < randomWord.length(); i++) {
                for (int j = 0; j < guess.length(); j++) {

                    if (randomWord.charAt(i) == guess.charAt(j) & letters.contains(String.valueOf(guess.charAt(j))) | randomWord.charAt(i) == guess.toUpperCase().charAt(j) & letters.contains(String.valueOf(guess.toUpperCase().charAt(j)))) {
                        count++;
                        guessContainer.set(i, String.valueOf(randomWord.charAt(i)));
                        letters.set(i, "_");
                        //System.out.println("Guess was lower case: " + guess.charAt(j));
                        break;
                    }
                }
                System.out.print(" " + guessContainer.get(i));
            }



            switch(livesAmount) {
                case 8:
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    System.out.println("   |------|");
                    System.out.println("   |      |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("     -----|-----");
                    break;

                case 7:
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    System.out.println("   |------|");
                    System.out.println("   |      |");
                    System.out.println("   O      |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("     -----|-----");
                    break;

                case 6:
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    System.out.println("   |------|");
                    System.out.println("   |      |");
                    System.out.println("   O      |");
                    System.out.println("   |      |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("     -----|-----");
                    break;
                case 5:
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    System.out.println("   |------|");
                    System.out.println("   |      |");
                    System.out.println("   O      |");
                    System.out.println("   |\\     |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("     -----|-----");
                    break;
                case 4:
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    System.out.println("   |------|");
                    System.out.println("   |      |");
                    System.out.println("   O      |");
                    System.out.println("  /|\\     |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("     -----|-----");
                    break;
                case 3:
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    System.out.println("   |------|");
                    System.out.println("   |      |");
                    System.out.println("   O      |");
                    System.out.println("  /|\\     |");
                    System.out.println("    \\     |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("     -----|-----");
                    break;
                case 2:
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    System.out.println("   |------|");
                    System.out.println("   |      |");
                    System.out.println("   O      |");
                    System.out.println("  /|\\     |");
                    System.out.println("  / \\     |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("     -----|-----");
                    break;
                case 1:
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    System.out.println("   |------|");
                    System.out.println("   |      |");
                    System.out.println("   O      |");
                    System.out.println("  /|\\     |");
                    System.out.println(" _/ \\     |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("     -----|-----");
                    break;
                case 0:
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    System.out.println("   |------|");
                    System.out.println("   |      |");
                    System.out.println("   O      |");
                    System.out.println("  /|\\     |");
                    System.out.println(" _/ \\_     |");
                    System.out.println("          |");
                    System.out.println("          |");
                    System.out.println("     -----|-----");
                    break;
                default:

            }

            if (livesAmount == 0 | count == randomWord.length()) {
                won = false;
            }
        } while (won);

        if(livesAmount <= 0){
            System.out.println("\nYou were hung! The word was " + randomWord);
        }else
        {
            System.out.println("\nYou won! The word was " + randomWord);
        }

    }
}
